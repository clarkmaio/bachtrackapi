"""FastAPI backend for Bachtrack opera events API."""
