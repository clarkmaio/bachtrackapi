"""Business logic and service layer."""
